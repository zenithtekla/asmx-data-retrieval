ALTER TABLE mantis_plugin_Serials_customer_table
ADD COLUMN status BINARY, timestamp int(10)